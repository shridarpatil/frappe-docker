# 3rd party libraries

Import / Upgrade Guide

## JQuery UI

Download modules

- core
- interactions
- autocomplete
- datepicker

## JQuery UI Bootstrap theme

Changes images urls

- from: url(images
- to: url(../lib/js/lib/jquery/bootstrap_theme/images

## JQuery Gantt

Not a very mature project. Please check css / js after updating