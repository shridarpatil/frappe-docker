import { Chart } from "frappe-charts"

frappe.Chart = Chart;
